package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafeFoodWebSpring서울8반송다은윤규희Application {

	public static void main(String[] args) {
		SpringApplication.run(SafeFoodWebSpring서울8반송다은윤규희Application.class, args);
	}

}
