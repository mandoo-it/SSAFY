package com.ssafy.fms.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.fms.service.BoardService;
import com.ssafy.fms.vo.Board;
import com.ssafy.fms.vo.Member;

@Controller
public class BoardController {
	@Autowired
	BoardService bservice;
	
	@GetMapping("/boardlist")
	public String boardlist(Model model,  HttpSession session) {
		model.addAttribute("list", bservice.selectAll());
		return "board";
	}
	
	@GetMapping("/detailboard/{num}")
	public String readboard(Model model , @PathVariable String num) {
	
		model.addAttribute("b", bservice.selectOne(num));
		return "boardinfo";
	}
	
	@GetMapping("/boarddelete/{num}")
	public String boarddelete(Model model , @PathVariable String num, HttpSession session) {
		
		if(session.getAttribute("login") == null || !session.getAttribute("login").equals("ssafy")) {
			return "login";
		}
		
		bservice.delete(num);
		return "redirect:/boardlist";
	}
	
	@GetMapping("/boardupdate/{num}")
	
	public String boardupdate(Model model , @PathVariable String num, HttpSession session) {
		
		if(session.getAttribute("login") == null || !session.getAttribute("login").equals("ssafy")) {
			return "login";
		}
		model.addAttribute("b", bservice.selectOne(num));
		return "boardupdate";
	}
	
	@PostMapping("/boardupdate")
	public String boardupdate2(Model model , Board b,HttpSession session) {
		
		if(session.getAttribute("login") == null || !session.getAttribute("login").equals("ssafy")) {
			return "login";
		}
		bservice.update(b);
		model.addAttribute("list", bservice.selectAll());
		return "board";
	}
	
	@GetMapping("/boardinsert")
	public String boardinsert(Board b, Model model,HttpSession session) {
		
		if(session.getAttribute("login") == null || !session.getAttribute("login").equals("ssafy")) {
			return "login";
		}
		return "boardinsert";
	}
	
	@PostMapping("/boardinsert")
	public String boardinsert2(Board b, Model model,HttpSession session) {
		
		if(session.getAttribute("login") == null || !session.getAttribute("login").equals("ssafy")) {
			return "login";
		}
		bservice.insert(b);
		model.addAttribute("list", bservice.selectAll());
		return "board";
	}
}
