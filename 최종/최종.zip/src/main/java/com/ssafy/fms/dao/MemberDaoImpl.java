package com.ssafy.fms.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.fms.vo.Member;

@Repository
public class MemberDaoImpl implements MemberDao{
	@Autowired
	SqlSession session;

	@Override
	public void add(Member member) {
		session.insert("fms.member.insert", member);
	}

	@Override
	public void update(Member member) {
		System.out.println("here");
		session.update("fms.member.update", member);
	}

	@Override
	public void delete(String id) {
		session.insert("fms.member.delete", id);
	}

	@Override
	public List<Member> searchAll() {
		return session.selectList("fms.member.selectAll");
	}

	@Override
	public Member search(String id) {
		return session.selectOne("fms.member.selectOne",id);
	}


}
