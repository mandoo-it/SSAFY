package com.ssafy.fms.vo;

public class Add {
	private String id;
	private int code;
	private int count;
	
	public Add() {}
	
	public Add(String id, int code, int count) {
		this.id = id;
		this.code = code;
		this.count = count;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public int getCode() {
		return code;
	}
	
	public void setCode(int code) {
		this.code = code;
	}
	
	public int getCount() {
		return count;
	}
	
	public void setCount(int count) {
		this.count = count;
	}

	
	
}
