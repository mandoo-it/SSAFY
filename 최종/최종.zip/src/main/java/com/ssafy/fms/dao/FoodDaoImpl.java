package com.ssafy.fms.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.fms.vo.Food;
import com.ssafy.fms.vo.Member;

@Repository
public class FoodDaoImpl implements FoodDao {
	@Autowired
	SqlSession session;

	@Override
	public List<Food> selectAll() {
		return session.selectList("fms.food.selectAll");
	}

	@Override
	public Food selectOne(int code) {
		return session.selectOne("fms.food.selectOne", code);
	}

	@Override
	public List<Food> search(String condition, String word) {
		if (condition.equals("name"))
			return session.selectList("fms.food.searchName", word);
		else if (condition.equals("maker"))
			return session.selectList("fms.food.searchMaker", word);
		else {
			return session.selectList("fms.food.searchMaterial", word);
		}
	}

	@Override
	public void Countup(int code) {
		session.update("fms.food.countUp", code);
	}

}
