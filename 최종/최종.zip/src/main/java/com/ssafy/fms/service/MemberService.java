package com.ssafy.fms.service;

import java.util.List;

import com.ssafy.fms.vo.Member;

public interface MemberService {
	
	public void add(Member member);
	public void update(Member member);
	public void delete(String id);
	public List<Member> searchAll();
	public Member search(String id);
	
}