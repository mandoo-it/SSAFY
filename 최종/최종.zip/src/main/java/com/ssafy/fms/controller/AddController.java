package com.ssafy.fms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ssafy.fms.service.AddService;
import com.ssafy.fms.service.FoodService;
import com.ssafy.fms.vo.Add;
import com.ssafy.fms.vo.Intake;


@Controller
public class AddController {

	@Autowired
	AddService service;
	@Autowired
	FoodService fservice;
	
	@GetMapping("/addlist")
	public String intakelist(HttpSession session, Model model) {
		
		//로그인이 안되어있으면
		if(session.getAttribute("login") == null) {
			try {
				return "redirect:/login";
			} catch (Exception e) {
				e.printStackTrace();
				
			}
		}
		
		String id = (String) session.getAttribute("login");
		List<Add> list = service.selectAll(id);
		List<Intake> list2 = new ArrayList();
		
		for (Add add : list) {
			String name = fservice.selectOne(add.getCode()).getName();
			list2.add(new Intake(id, add.getCode(), name, add.getCount(), " "));
		}
		
		model.addAttribute("list", list2);
		return "myaddinfo";
	}
	
	@GetMapping("/add/{code}")
	public String insert(HttpSession session, Model model, @PathVariable int code) {
		
		//로그인이 안되어있으면
		if(session.getAttribute("login") == null) {
			try {
				return "redirect:/login";
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		String id = (String) session.getAttribute("login");
		List<Add> list = service.selectAll(id);
		boolean check = false;
		for (Add add : list) {
			if(add.getCode() == code) {
				service.update(add);
				check = true;
				break;
			}
		}
		
		if(check == false) {
			service.insert(new Add(id, code, 1));
		}
		
		model.addAttribute("list", list);
		return "redirect:/addlist";
		//return "redirect:/detailinfo/"+ code;
		//return "myintakeinfo";
	}
	
	@GetMapping("/delete/{code}")
	public String delete(HttpSession session, Model model, @PathVariable int code) {
		
		//로그인이 안되어있으면
		if(session.getAttribute("login") == null) {
			try {
				return "redirect:/login";
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		String id = (String) session.getAttribute("login");
		List<Add> list = service.selectAll(id);
		service.delete(new Add(id, code, 0));
		
		model.addAttribute("list", list);
		return "redirect:/addlist";
		//return "redirect:/detailinfo/"+ code;
		//return "myintakeinfo";
	}


}
