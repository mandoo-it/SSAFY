package com.ssafy.fms.vo;

public class Intake {
	private String id;
	private int code;
	private String name;
	private int count;
	private String date;
	
	public Intake() {}
	
	public Intake(String id, int code,String name, int count, String date) {
		this.id = id;
		this.code = code;
		this.name = name;
		this.count = count;
		this.date = date;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	
}
