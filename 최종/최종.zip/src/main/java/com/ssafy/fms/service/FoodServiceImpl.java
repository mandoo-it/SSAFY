package com.ssafy.fms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.fms.dao.FoodDao;
import com.ssafy.fms.vo.Food;

@Service
public class FoodServiceImpl implements FoodService {
	@Autowired
	FoodDao dao;

	@Override
	public List<Food> selectAll() {
		return dao.selectAll();
	}

	@Override
	public Food selectOne(int code) {
		return dao.selectOne(code);
	}

	@Override
	public List<Food> search(String condition, String word) {
		return dao.search(condition, word);
	}

	@Override
	public void Countup(int code) {
		dao.Countup(code);
	}

	
	
}
