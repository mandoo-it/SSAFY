package com.ssafy.fms.service;

import java.util.List;

import com.ssafy.fms.vo.Food;

public interface FoodService {

public List<Food> selectAll();
	
	public Food selectOne(int code);

	public List<Food> search(String condition, String word);
	
	public void Countup(int code);
	
}
