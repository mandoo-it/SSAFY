package com.ssafy.fms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.fms.dao.MemberDao;
import com.ssafy.fms.vo.Member;

@Service
public class MemberServiceImpl implements MemberService {
	@Autowired
	MemberDao dao;

	@Override
	public void add(Member member) {
		dao.add(member);
	}

	@Override
	public void update(Member member) {
		dao.update(member);
	}

	@Override
	public void delete(String id) {
		dao.delete(id);
	}

	@Override
	public List<Member> searchAll() {
		return dao.searchAll();
	}

	@Override
	public Member search(String id) {
		return dao.search(id);
	}
	
}
