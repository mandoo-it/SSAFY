drop table member;
create table member( 
 id varchar(20) primary key, 
 pass varchar(20) not null,
 name varchar(20) not null,
 address varchar(30),
 callnum varchar(30),
 allegy varchar(30)
);
insert into member values('admin', 'admin', '황정호', 'seoul',
     '01083289424','땅콩');
insert into member values('ssafy', 'ssafy', '신채민', 'seoul',
     '01083289424','우유');
commit;
select * from member;