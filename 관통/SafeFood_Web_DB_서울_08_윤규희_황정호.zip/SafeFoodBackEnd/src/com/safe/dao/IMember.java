package com.safe.dao;

import java.util.List;

import com.safe.vo.Member;

public interface IMember {
	public Member login(String id, String pass);
	
	public void join(Member member);
	
	public void delete(String id);
}
