package com.safe.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import com.config.MyBatisUtil;
import com.safe.vo.Food;

public class FoodDaoImpl implements FoodDao {
	String driver = "com.mysql.cj.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/tommy?serverTimezone=UTC&useUnicode=yes&characterEncoing=UTF-8";
	String user = "scott";
	String password = "tiger";

	List<Food> list;

	public FoodDaoImpl() {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} // 1.
		list = new ArrayList<Food>();
	}

	public Connection getConnection() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(url, user, password); // 2-1
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

	/**
	 * 검색 조건(key) 검색 단어(word)에 해당하는 식품 정보(Food)의 개수를 반환. web에서 구현할 내용. web에서 페이징 처리시
	 * 필요
	 * 
	 * @param bean 검색 조건과 검색 단어가 있는 객체
	 * @return 조회한 식품 개수
	 */
	public int foodCount(String key, String word) {
		// 구현하세요.
		int cnt = 0;
		String query = "select count(*) from foods where " + key + " = " + word;
		Connection con = null;
		Statement stat = null;
		ResultSet rs = null;
		try {
			con = getConnection(); // 2-2
			stat = con.createStatement();
			rs = stat.executeQuery(query); // 4
			cnt = rs.getInt(1);
		} catch (Exception e) {
		}
		return cnt;
	}

	/**
	 * 검색 조건(key) 검색 단어(word)에 해당하는 식품 정보(Food)를 검색해서 반환.
	 * 
	 * @param bean 검색 조건과 검색 단어가 있는 객체
	 * @return 조회한 식품 목록
	 */
	public List<Food> searchAll(String key, String word) {
		List<Food> finds = new LinkedList<Food>();
		String query = new String();

		if (key.equals("상품명"))
			key = "name";
		else if (key.equals("제조사"))
			key = "maker";
		else if (key.equals("재료명"))
			key = "material";

		Map<String, String> m = new HashMap<String, String>();
		m.put("key", key);
		m.put("word", word);
		SqlSession session = MyBatisUtil.getSqlSession();
		return session.selectList("food.selectAll", m);

	}

	/**
	 * 식품 코드에 해당하는 식품정보를 검색해서 반환.
	 * 
	 * @param code 검색할 식품 코드
	 * @return 식품 코드에 해당하는 식품 정보, 없으면 null이 리턴됨
	 */
	public Food search(int code) {
		
		SqlSession session = MyBatisUtil.getSqlSession();
		return (Food) session.selectOne("food.selectOne", code);

	}

	/**
	 * 가장 많이 검색한 Food 정보 리턴하기 web에서 구현할 내용.
	 * 
	 * @return
	 */
	public List<Food> searchBest() {
		return null;
	}

	public List<Food> searchBestIndex() {
		return null;
	}

	public static void print(List<Food> foods) {
		for (Food food : foods) {
			System.out.println(food);
		}
	}

	public void close(ResultSet rs, Statement stat, PreparedStatement pstat, Connection con) {
		try {
			if (rs != null)
				rs.close();
			if (stat != null)
				stat.close();
			if (pstat != null)
				pstat.close();
			if (con != null)
				con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static int n, r;
	public static double min = Double.MAX_VALUE;
	public static double cal;
	public static Food[] arr;
	public static List<Food> listCal = new ArrayList<Food>();

	public void comb(int start, int flag, int count) {
		if (count == r) {
			double tmp = 0;
			for (int i = 0; i < arr.length; i++) {
				tmp += arr[i].getCalory();
			}
			if (min > (cal - tmp) && tmp < cal) {
				listCal.clear();
				for (int i = 0; i < arr.length; i++) {
					listCal.add(arr[i]);
				}
				min = cal - tmp;
			}
			return;
		}
		for (int i = start; i < n; i++) {
			if ((flag & 1 << i) == 0) {
				arr[count] = list.get(i);
				comb(i + 1, flag | 1 << i, count + 1);
			}
		}
	}

	@Override
	public List<Food> searchCal(String word) {
		list = searchAll("all", null);
		n = list.size();
		cal = Double.parseDouble(word);
		for (int i = 0; i < n; i++) {
			r = i;
			arr = new Food[r];
			comb(0, 0, 0);
		}
		return listCal;
	}
}
