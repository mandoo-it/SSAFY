package com.safe.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.safe.dao.MemberDAO;
import com.safe.vo.Member;

public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	MemberDAO dao = new MemberDAO();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void joinForm(HttpServletRequest req, HttpServletResponse res) {
		RequestDispatcher dis = req.getRequestDispatcher("/view/join.html");
		try {
			dis.forward(req, res);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	public void join(HttpServletRequest req, HttpServletResponse res) {

		String id = req.getParameter("id");
		String pass = req.getParameter("pass");
		String name = req.getParameter("name");
		String address = req.getParameter("address");
		String call = req.getParameter("callnum");

		String[] allegyArr = req.getParameterValues("allergy");

		String allegy = null;
		StringBuilder sb = new StringBuilder();
		
		if (allegyArr != null) {
			for (String str : allegyArr) {
				sb.append(str + ",");
			}
			allegy = sb.toString();
		}

		Member m = new Member(id, pass, name, address, call, allegy);
		System.out.println(m.toString());
		dao.join(m);
		try {
			res.sendRedirect("main.food");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void loginForm(HttpServletRequest req, HttpServletResponse res) {
		RequestDispatcher dis = req.getRequestDispatcher("/view/login.html");
		try {
			dis.forward(req, res);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	public void login(HttpServletRequest req, HttpServletResponse res) {
		String id = req.getParameter("id");
		String pass = req.getParameter("pass");

		System.out.println(id + " " + pass);

		Member m = dao.login(id, pass);
		if (dao.login(id, pass) != null) {
			HttpSession hs = req.getSession();
			hs.setAttribute("member", m);
			System.out.println("로그인 성공");
		} else {
			String msg = "아이디 또는 패스워드가 틀립니다.";
			req.setAttribute("msg", msg);
			System.out.println("로그인 실패");
		}

		try {
			res.sendRedirect("main.food");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void logout(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		req.getSession().invalidate();
		res.sendRedirect("main.food");
	}

	public void memberinfo(HttpServletRequest req, HttpServletResponse res) {

		RequestDispatcher dis = req.getRequestDispatcher("/view/memberinfo.jsp");

		try {
			dis.forward(req, res);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	public void editForm(HttpServletRequest req, HttpServletResponse res) {
		RequestDispatcher dis = req.getRequestDispatcher("/view/editpage.jsp");

		try {
			dis.forward(req, res);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	public void edit(HttpServletRequest req, HttpServletResponse res) {

		String id = req.getParameter("id");
		String address = req.getParameter("address");
		String callnum = req.getParameter("callnum");
		String Opass=req.getParameter("Opass");
		String Npass=req.getParameter("Npass");

		String[] allegyArr = req.getParameterValues("allergy");
		String allegy = null;
		StringBuilder sb = new StringBuilder();
		if (allegyArr != null) {
			for (String str : allegyArr) {
				sb.append(str + ",");
			}
			allegy = sb.toString();
		}
		
		dao.update(id, Opass, Npass, address, callnum, allegy);

		HttpSession hs = req.getSession();
		Member m = (Member) hs.getAttribute("member");
		m.setAddress(address);
		m.setCallnum(callnum);
		m.setAllegy(allegy);

		RequestDispatcher dis = req.getRequestDispatcher("/view/memberinfo.jsp");

		try {
			dis.forward(req, res);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	public void quit(HttpServletRequest req, HttpServletResponse res) throws IOException {
		
		String id=req.getParameter("id");
		dao.delete(id);
		
		req.getSession().invalidate();
		res.sendRedirect("main.food");
	}

	public void quitConfirm(HttpServletRequest req, HttpServletResponse res) {
		String id=req.getParameter("id");
		req.setAttribute("id", id);
		RequestDispatcher dis = req.getRequestDispatcher("/view/quit.jsp");
		
		try {
			dis.forward(req, res);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	public void pass(HttpServletRequest req, HttpServletResponse res) {
		RequestDispatcher dis = req.getRequestDispatcher("/view/pass.jsp");
		
		try {
			dis.forward(req, res);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	public void passProcess(HttpServletRequest req, HttpServletResponse res) throws IOException {
		String id=req.getParameter("id");
		String name=req.getParameter("name");
		String callnum = req.getParameter("callnum");
		
		String newPass=dao.newPass(id,name,callnum);
		
		if(newPass==null) {
			String msg = "회원정보가 없습니다.";
			req.setAttribute("msg", msg);
			System.out.println("임시 비밀번호 발급 성공");
			try {
				res.sendRedirect("main.food");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		else {
			String msg = "임시 비밀번호를 발급했습니다.";
			req.setAttribute("msg", msg);
			req.setAttribute("newPass", newPass);
			System.out.println("임시 비밀번호 발급 성공");
			RequestDispatcher dis = req.getRequestDispatcher("/view/passSuccess.jsp");
			
			try {
				dis.forward(req, res);
			} catch (ServletException | IOException e) {
				e.printStackTrace();
			}
		}
		
	}

}
