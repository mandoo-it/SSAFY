package com.safe.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.TreeMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.safe.dao.FoodDao;
import com.safe.dao.FoodDaoImpl;
import com.safe.vo.Food;
import com.safe.vo.Word;

@WebServlet("/SafeFoodController")
public class SafeFoodController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	FoodDao dao = new FoodDaoImpl();
	static List<Word> trends = new ArrayList<>();
	String[] allergy = { "대두", "땅콩", "우유", "게", "새우", "참치", "연어", "쑥", "소고기", "닭고기", "복숭아", "민들레", "계란흰자" };

	public void list(HttpServletRequest req, HttpServletResponse res) {
		
		ServletContext app = req.getServletContext();

		String key = req.getParameter("key");
		
		if (key == null)
			key = "all";
		String word = req.getParameter("word");

		if (word != null)
			trendWord(word);
		app.setAttribute("trends", trends);

		List<Food> list = new ArrayList<Food>();
		if(!key.equals("all") && word != null && !word.trim().equals("")) {
			if(key.equals("칼로리")) {
				try {
					res.sendRedirect("cal.food?word="+word);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			else {
				list=dao.searchAll(key, word);
			}
		}
		else {
			list=dao.searchAll("all",null);
		}
		req.setAttribute("list", list);//jsp에서 꺼내쓰도록 list 저장
		
		//jsp로 forward해서 넘어가기
		RequestDispatcher dis=req.getRequestDispatcher("/view/index.jsp");
		try {
			dis.forward(req, res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void read(HttpServletRequest req, HttpServletResponse res) {
		String key = req.getParameter("key");
		if (key == null)
			key = "all";
		String word = req.getParameter("word");
		ServletContext app = req.getServletContext();

		if (word != null)
			trendWord(word);
		app.setAttribute("trends", trends);

		List<Food> list = new ArrayList<Food>();
		if(!key.equals("all") && word != null && !word.trim().equals("")) {
			if(key.equals("칼로리")) {
				try {
					res.sendRedirect("cal.food?word="+word);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			else {
				list=dao.searchAll(key, word);
			}
		}
		else list=dao.searchAll("all",null);
		req.setAttribute("list", list);//jsp에서 꺼내쓰도록 list 저장
		
		//jsp로 forward해서 넘어가기
		RequestDispatcher dis=req.getRequestDispatcher("/view/read.jsp");
		try {
			dis.forward(req, res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void detail(HttpServletRequest req, HttpServletResponse res) {
		int code = Integer.parseInt(req.getParameter("code"));
		Food f = dao.search(code);

		String meterial = f.getMaterial();
		String allergy = findAllergy(meterial);

		req.setAttribute("f", f);
		req.setAttribute("a", allergy);
		RequestDispatcher dis = req.getRequestDispatcher("/view/detail.jsp");
		try {
			dis.forward(req, res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void cal(HttpServletRequest req, HttpServletResponse res) {
		String word=req.getParameter("word");
		List<Food> list = new ArrayList<Food>();
		
		list=dao.searchCal(word);
		
		double cal=0.0;
		for(int i=0;i<list.size();i++) {
			cal+=list.get(i).getCalory();
		}
		
		String str=String.format("%.2f",cal);
		req.setAttribute("cal",str);
		req.setAttribute("list", list);
		
		RequestDispatcher dis=req.getRequestDispatcher("/view/cal.jsp");
		try {
			dis.forward(req, res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void trendWord(String word) {
		boolean flag = true;

		for (Word w : trends) {
			if (w.word.equals(word)) {
				w.cnt++;
				flag = false;
				break;
			}
		}

		if (flag) {
			trends.add(new Word(word, 1));
		}

		trends.sort(new Comparator<Word>() {

			@Override
			public int compare(Word o1, Word o2) {
				return Integer.compare(o2.cnt, o1.cnt);
			}
		});
	}

	public String findAllergy(String meterial) {

		StringBuilder sb = new StringBuilder();
		for (String a : allergy) {
			if(meterial.contains(a)) {
				sb.append(a).append(",");
			}
		}

		return sb.toString();
	}

}
