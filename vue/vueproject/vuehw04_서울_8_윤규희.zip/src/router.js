import Vue from "vue";
import Router from "vue-router";
import BoardsList from "./components/BoardsList.vue";
import BoardDetail from "./components/BoardDetail.vue";
import AddBoard from "./components/AddBoard.vue";
import UpdateBoard from "./components/UpdateBoard.vue";

Vue.use(Router);

export default new Router({
    mode : "history",
    routes : [
        {
            path : "/",
            name : "boards",
            component : BoardsList
        },
        {
            path : "/detailboard/:num",
            name : "detailboard",
            component : BoardDetail,
            props : true
        },
        {
            path: "/add",
            name: "add",
            component: AddBoard
        },
        {
            path: "/update/:bodnum",
            name: "update",
            component: UpdateBoard,
            props : true
          }
    ]

});