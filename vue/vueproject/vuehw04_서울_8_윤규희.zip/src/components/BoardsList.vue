<template>
  <div>
    <div>
      <table class='list_table'>
      <col width="10%"><col width="20%">
      <col width="20%"><col width="20%"><col width="10%">
      <col width="10%">
      <tr>
        <th>번호</th>
        <th>이름</th>
        <th>제목</th>
        <th>내용</th>
        <th>날짜</th>
        <th>조회수</th>
        <th>삭제</th>
        
      </tr>
      <tr v-for="bod in boards" class="nicecolor" :key="bod.num">
        <td v-html="bod.num" @click="show_detail(bod.num)"></td>
        <td v-html="bod.name"></td>
        <td v-html="bod.title"></td>
        <td v-html="bod.content"></td>
        <td v-html="bod.wdate"></td>
        <td v-html="bod.count"></td>
        <td class='button' @click="delete_bod(bod.num)"><input type="button" class='blue' value='삭제'></td>
      </tr>
      </table>
      </div>
  </div>
</template>

<script>
import http from "../http-common";
export default {
  name : "boards-list",
  data(){
    return{
      boards: [],
      loading: true,
      errored: false 
    }
  },
  methods:{
    retrieveBoards(){
      http
        .get('/boards')
        .then(response => (this.boards = response.data))
        .catch(() => {
          this.errored = true
        })
        .finally(() => this.loading = false)
    },
    delete_bod(bodnum){
      alert(bodnum+"번 글을 삭제합니다.");
      http
        .delete('/boards/'+bodnum)
        .then(response => {
          if (response.data.result=='delete success!!') {
            alert("삭제하였습니다.");
            this.retrieveBoards();
          }else{
            alert("삭제하지 못했습니다.");
          }
        })
        .catch()
        .finally(() => this.loading = false);
    },
    show_detail:function(bodnum){
      alert(bodnum + "게시물입니다.");
      this.$router.push("/detailboard/"+bodnum);
    }  
  },
  mounted(){
    this.retrieveBoards();
  }
}
</script>

<style>

</style>