<template>
  <div>
    <div>
      <form action method="post" id="_frmForm" name="frmForm" @submit.prevent="addBoard">
        <table class="content_table">
          <colgroup>
            <col style="width:30%;" />
            <col style="width:70%;" />
          </colgroup>
          <tr>
            <th>작성자</th>
            <td>
              <input
                data-msg="작성자"
                type="text"
                name="name"
                id="_name"
                v-model="name"
                style="width:30%"
              />
            </td>
          </tr>
           <tr>
            <th>글 비밀번호</th>
            <td>
              <input
                data-msg="비밀번호"
                type="password"
                name="pass"
                id="pass"
                v-model="pass"
                style="width:30%"
              />
            </td>
          </tr>
          <tr>
            <th>제목</th>
            <td>
              <input
                data-msg="제목"
                type="text"
                name="title"
                id="title"
                size="20"
                v-model="title"
                style="width:30%"
              />
            </td>
          </tr>
          <tr>
            <th>내용</th>
            <td>
              <input
                data-msg="내용"
                type="text"
                name="content"
                id="content"
                size="30"
                v-model="content"
                style="width:30%"
              />
            </td>
          </tr>

          <tr>
            <td colspan="2" style="height:50px; text-align:center;">
              <button type="submit" name="button">글 추가</button>
            </td>
          </tr>
        </table>
      </form>
    </div>
  </div>
</template>

<script>
import http from "../http-common";

export default {
  name: "add-customer",
  data() {
    return {
     num : "",
     name : "",
     title : "",
     content : "",
     count : "",
     pass :"",
     submitted: false
    };
  },
  filters: {
    salarydecimal(value) {
      var a = parseInt(value);
      return a.toFixed(2);
    }
  },
  methods: {
    addBoard() {
      if (this.name == "") {
        alert("작성자 입력하세요.");
        return;
      }
       if (this.title == "") {
        alert("제목 입력하세요.");
        return;
      }
       if (this.content == "") {
        alert("내용 입력하세요.");
        return;
      }
      

      http
        .post("/boards", {
            name : this.name,
            title : this.title,
            content : this.content,
            pass : this.pass,
        })
        .then(response => {
          if (response.data.result != "insert success!!") {
            alert("실패");
          } else {
              this.$router.push("/");
          }
        });
      this.submitted = true;
    },
    newCustomer() {
      (this.name = ""), (this.title = ""), (this.content = ""), (this.pass = "");
    }
  }
};
</script>

<style>
.submitform {
  max-width: 300px;
  margin: auto;
}
</style>
