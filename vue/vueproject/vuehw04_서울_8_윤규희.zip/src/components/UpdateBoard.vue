<template>
  <div>
    <div>
      <form action method="post" id="_frmForm" name="frmForm" @submit.prevent="updateBoard">
        <table class="content_table">
          <colgroup>
            <col style="width:30%;" />
            <col style="width:70%;" />
          </colgroup>
          <tr>
            <th>작성자</th>
            <td>
              <input
                data-msg="작성자"
                type="text"
                name="name"
                id="_name"
                v-model="bod.name"
                style="width:30%"
              />
            </td>
          </tr>
           <tr>
            <th>글 비밀번호</th>
            <td>
              <input
                data-msg="비밀번호"
                type="password"
                name="pass"
                id="pass"
                v-model="bod.pass"
                style="width:30%"
              />
            </td>
          </tr>
          <tr>
            <th>제목</th>
            <td>
              <input
                data-msg="제목"
                type="text"
                name="title"
                id="title"
                size="20"
                v-model="bod.title"
                style="width:30%"
              />
            </td>
          </tr>
          <tr>
            <th>내용</th>
            <td>
              <input
                data-msg="내용"
                type="text"
                name="content"
                id="content"
                size="30"
                v-model="bod.content"
                style="width:30%"
              />
            </td>
          </tr>

          <tr>
            <td colspan="2" style="height:50px; text-align:center;">
              <button type="submit" name="button">글 수정하기</button>
            </td>
          </tr>
        </table>
      </form>
    </div>
  </div>
</template>


<script>
import http from "../http-common";

export default {
  name: "add-customer",
  props:['bodnum'],
  data() {
    return{
      bod: []
    }
  },
  filters: {
    salarydecimal(value) {
      var a = parseInt(value);
      return a.toFixed(2);
    }
  },
  methods: {
    updateBoard() {
      if (this.name == "") {
        alert("작성자 입력하세요.");
        return;
      }
       if (this.title == "") {
        alert("제목 입력하세요.");
        return;
      }
       if (this.content == "") {
        alert("내용 입력하세요.");
        return;
      }
      

      http
        .put("/boards", {
            title : this.bod.title,
            content : this.bod.content,
            num : this.bod.num,
        })
        .then(response => {
          if (response.data.result != "update success!!") {
            alert("실패");
          } else {
              this.$router.push("/");
          }
        });
      this.submitted = true;
    },
     detailBoard(){
      http
        .get('/boards/' + this.bodnum)
        .then(response => (this.bod = response.data))
        .catch(() => {
          this.errored = true
        })
        .finally(() => this.loading = false)
    },
      update(num){
        this.$router.push("/update/"+num);
    },
    newCustomer() {
      (this.name = ""), (this.title = ""), (this.content = ""), (this.pass = "");
    }
  }, mounted() {
      this.detailBoard();
  }

};
</script>

<style>
.submitform {
  max-width: 300px;
  margin: auto;
}
</style>
