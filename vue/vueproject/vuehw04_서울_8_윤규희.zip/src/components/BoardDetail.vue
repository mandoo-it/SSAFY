<template>
  <div>
      <table class='list_table'>
      <col width="10%">
      <col width="20%">
      <col width="20%">
      <col width="20%">
      <col width="10%">
      <col width="10%">
      <tr>
        <th>번호호</th>
        <th>이름</th>
        <th>제목</th>
        <th>내용</th>
        <th>날짜</th>
        <th>조회수</th>
      </tr>
      <tr>
        <td v-html="bod.num"></td>
        <td v-html="bod.name"></td>
        <td v-html="bod.title"></td>
        <td v-html="bod.content"></td>
        <td v-html="bod.wdate"></td>
        <td v-html="bod.count"></td>
      </tr>
      </table>
      <input type="button" class='blue' value='수정하기' @click="update(bod.num)">
  </div>
</template>

<script>
import http from "../http-common";
export default {
  name : "detailboard",
  props:['num'],
  data(){
    return{
      bod: []
    }
  },
  methods:{
    detailBoard(){
      http
        .get('/boards/' +this.num)
        .then(response => (this.bod = response.data))
        .catch(() => {
          this.errored = true
        })
        .finally(() => this.loading = false)
    },
      update(num){
        this.$router.push("/update/"+num);
    }
  },
  mounted(){
    this.detailBoard();
  }
}
</script>

<style>
</style>