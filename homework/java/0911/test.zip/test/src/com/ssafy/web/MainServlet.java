package com.ssafy.web;

import java.io.Console;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/main.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public MainServlet() {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String action = request.getParameter("action");
		
		if(action!=null && action.equals("Login")) {
			String id = request.getParameter("id");
			String pass = request.getParameter("pass");
			if(id.equals("ssafy") && pass.equals("1111")) {
				response.sendRedirect("Result.html");
			}
			else {
				response.sendRedirect("Login.html");
			}
		}
		else if(action!=null && action.equals("register")) {
			
			String title = request.getParameter("title");
			String isbn1 = request.getParameter("isbn1");
			String isbn2 = request.getParameter("isbn2");
			String isbn3 = request.getParameter("isbn3");
			String genre = request.getParameter("genre");
			
			String nation = request.getParameter("nation");
			
			String date = request.getParameter("date");
			
			
			String publisher = request.getParameter("publisher");
			String author = request.getParameter("author");
			String money1 = request.getParameter("money1");
			String money2 = request.getParameter("money2");
			
			String content = request.getParameter("content");
			if(content == null) content = "";
			
			out.print("<!DOCTYPE html>");
			out.print("<html>");
			out.print("<head>");
//			out.print("<style>");
//			out.print("table{border: 1px #444444;}");
//			out.print("th{padding : 10px; width:100px; border: 1px solid #444444;}");
//			out.print("td{padding : 10px; width:500px; border: 1px solid #444444;}");
//			out.print("</style>");
			out.print("<style type='text/css'>td, th { border: 1px solid black;border-color: gray;padding : 10px;align : center;text-align : center;} "
					+ "h2 { align : center;	text-align : center;}table{border: 1px solid black;;}</style>");
			out.print("</head>");
			out.print("<body>");
			out.print("<div align='center'><h2>도서정보<h2></div>");
			out.print("<div align='center'>");
			out.print("<table>");
			out.print("<tr>");
			out.print("<th>도서명</th>");				
			out.print("<td>" + title + "</td>");				
			out.print("</tr>");
			
			out.print("<tr>");
			out.print("<th>도서번호</th>");				
			out.print("<td>" + isbn1 + " - " + isbn2 + " - "  + isbn3 + "</td>");				
			out.print("</tr>");
			
			out.print("<tr>");
			out.print("<th>도서분류</th>");				
			out.print("<td>" + genre +"</td>");				
			out.print("</tr>");
			
			out.print("<tr>");
			out.print("<th>도서국가</th>");				
			out.print("<td>" + nation +"</td>");				
			out.print("</tr>");
			
			out.print("<tr>");
			out.print("<th>출판일</th>");				
			out.print("<td>" + date +"</td>");				
			out.print("</tr>");
			
			out.print("<tr>");
			out.print("<th>출판사</th>");				
			out.print("<td>" + publisher +"</td>");				
			out.print("</tr>");
			
			out.print("<tr>");
			out.print("<th>저자</th>");				
			out.print("<td>" + author +"</td>");				
			out.print("</tr>");
			
			out.print("<tr>");
			out.print("<th>도서가격</th>");				
			out.print("<td>" + money1 + money2+"</td>");				
			out.print("</tr>");
			
			out.print("<tr>");
			out.print("<th>도서설명</th>");				
			out.print("<td>" + content +"</td>");				
			out.print("</tr>");

			out.print("</table></div>");
			
			
			out.print("<br><div align='center'><a href = 'Book.html'>도서 등록</a></div>");
			out.print("</body>");
			out.print("</html>");
		}
	}






}
