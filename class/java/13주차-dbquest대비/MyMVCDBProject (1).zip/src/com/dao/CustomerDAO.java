package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.domain.Customer;

//DAO:DB�� �����ؼ� CRUD(Create/Read/Update/Delete) �۾��� �����ϴ� ��ü
public class CustomerDAO implements ICustomer {

	// FIELD
	String driver = "com.mysql.cj.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	String user = "scott";
	String password = "tiger";

	// ������:1.Driver ���-> ������ ����� db ���
	public CustomerDAO() {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	// 2.Connection ���� - network ����	
	public Connection getConnection() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

	@Override
	public ArrayList<Customer> selectAll() {
		String q = "select * from customer order by num";
		ArrayList<Customer> list = new ArrayList<>();

		try {
			Connection con = getConnection();
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery(q);

			while (rs.next()) {
				String num = rs.getString(1);
				String name = rs.getString(2);
				String address = rs.getString(3);

				Customer c = new Customer(num, name, address);
				list.add(c);
			}
			close(stat, rs, con, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Customer selectOne(String num) {
		String q = "select * from customer where num = ?";
		Customer c = null;

		try {
			Connection con = getConnection();
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, num);
			ResultSet rs = pstmt.executeQuery();
			rs.next();

			String num1 = rs.getString(1);
			String name = rs.getString(2);
			String address = rs.getString(3);

			c = new Customer(num, name, address);

			close(null, rs, con, pstmt);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return c;
	}

	@Override
	public ArrayList<Customer> findByAddress(String address) {
		String q = "select * from customer where address = ?";
		ArrayList<Customer> list = new ArrayList<>();
		Customer c = null;
		try {
			Connection con = getConnection();
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, address);
			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {

				String num1 = rs.getString(1);
				String name = rs.getString(2);
				String add = rs.getString(3);

				list.add(new Customer(num1,name,add));
			}
			close(null, rs, con, pstmt);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public int insert(Customer c) {
		String q = "INSERT INTO CUSTOMER VALUES(?, ?, ?);";
		int rs = 0;
		try {
			Connection con = getConnection();
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, c.getNum());
			pstmt.setString(2, c.getName());
			pstmt.setString(3, c.getAddress());
			rs = pstmt.executeUpdate();

			close(null, null, con, pstmt);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return rs;
	}

	@Override
	public int update(String num, String address) {
		String q = "UPDATE CUSTOMER SET ADDRESS = ? WHERE NUM = ?";
		int rs = 0;
		try {
			Connection con = getConnection();
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, address);
			pstmt.setString(2, num);
			rs = pstmt.executeUpdate();

			close(null, null, con, pstmt);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return rs;
	}

	@Override
	public int delete(String num) {
		String q = "DELETE FROM CUSTOMER WHERE NUM = ?";
		int rs = 0;
		try {
			Connection con = getConnection();
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, num);
			rs = pstmt.executeUpdate();

			close(null, null, con, pstmt);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return rs;
	}

	// 서블릿에서 인터페이스형으로 선언하는 경우 close()메소드 사용불가
	public void close(Statement stat, ResultSet rs, Connection con, PreparedStatement pstat) {
		try {
			if (stat != null)
				stat.close();			
			if (pstat != null)
				pstat.close();

			if (rs != null)
				rs.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
