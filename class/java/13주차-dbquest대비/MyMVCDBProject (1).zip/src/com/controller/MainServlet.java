package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CustomerDAO;
import com.domain.Customer;

public class MainServlet extends HttpServlet {	
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}
	
	public void process(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		
		req.setCharacterEncoding("utf-8");		
		String action = req.getParameter("action");		
		//dao 객체 생성
		// 클래스 다이어그램 확인, 자료형이 인터페이스로 주어질 수 있음
		CustomerDAO dao = new CustomerDAO();

		// 모든 요청이 여기로 들어오므로 작업들이 여기로 와야한다.
		// 요청 -> controller -> model -> controller -> view
		if(action == null){//초기요청
			//dao에 db 작업 지시 후 결과 받기
			List<Customer> list = dao.selectAll();
			//req에 데이터 저장
			req.setAttribute("list", list);
			
			RequestDispatcher dis = req.getRequestDispatcher("view/index.jsp");
			dis.forward(req, res);
		
		}else if(action.equals("read")){//detail
			String n = req.getParameter("num");
			Customer c = dao.selectOne(n);
			req.setAttribute("customer", c);
			
			RequestDispatcher dis = req.getRequestDispatcher("view/detail.jsp");
			dis.forward(req, res);
			
		}else if(action.equals("insertForm")){//새 데이터 입력 화면, 초기화면에 링크로 표시
			RequestDispatcher dis = req.getRequestDispatcher("view/insertForm.jsp");
			dis.forward(req, res);
			
		}else if(action.equals("insertProcess")){//db에 insert
			String num = req.getParameter("num");
			String name = req.getParameter("name");
			String address = req.getParameter("address");
			
			Customer c = new Customer(num, name, address);
			// req.setAttribute("customer", c);
			
			int result = dao.insert(c);
			
			//dao에 db 작업 지시 후 결과 받기
			List<Customer> list = dao.selectAll();
			//req에 데이터 저장
			req.setAttribute("list", list);
			
			RequestDispatcher dis = req.getRequestDispatcher("view/index.jsp");
			dis.forward(req, res);
			
		}else if(action.equals("updateForm")){//수정 전 원래 데이터 보여주는 화면, 상세화면에 링크로 표시
			String n = req.getParameter("num");
			Customer c = dao.selectOne(n);
			 req.setAttribute("customer", c);
			
			RequestDispatcher dis = req.getRequestDispatcher("view/updateForm.jsp");
			dis.forward(req, res);
			
		}else if(action.equals("updateProcess")){//db 수정하기
			String num = req.getParameter("num");
			String address = req.getParameter("address");
			
			dao.update(num, address);
			
			//dao에 db 작업 지시 후 결과 받기
			List<Customer> list = dao.selectAll();
			//req에 데이터 저장
			req.setAttribute("list", list);
			
			RequestDispatcher dis = req.getRequestDispatcher("view/index.jsp");
			dis.forward(req, res);
			
		}else if(action.equals("delete")){//삭제, 상세화면에 링크로 표시
			String num = req.getParameter("num");
			dao.delete(num);
			
			//dao에 db 작업 지시 후 결과 받기
			List<Customer> list = dao.selectAll();
			//req에 데이터 저장
			req.setAttribute("list", list);
			
			RequestDispatcher dis = req.getRequestDispatcher("view/index.jsp");
			dis.forward(req, res);
			
		}else if(action.equals("findByAddress")){//주소로 검색
			String add = req.getParameter("search");
			
			List<Customer> list = dao.findByAddress(add);
			req.setAttribute("list", list);
			
			RequestDispatcher dis = req.getRequestDispatcher("view/result.jsp");
			dis.forward(req, res);
		}
	}
}